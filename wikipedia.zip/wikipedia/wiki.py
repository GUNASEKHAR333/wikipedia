import urllib.request,urllib.parse,urllib.error
from bs4 import BeautifulSoup
from googlesearch import search
print("Enter the information from wikipedia")
query=str(input())
a=list()
for j in search(query,num=100,stop=100):
	a.append(j)
result=list()
for k in a:
    if("wikipedia.org/wiki" in k):
        result.append(k)
query_list=query.split()
if(len(result)==0):
    print("given information is not in any of wikipedia pages")
else:
    for i in result:
        print("frequency of words in url ",i)
        html = urllib.request.urlopen(i).read()
        soup = BeautifulSoup(html, 'html.parser')
        text=soup.get_text()
        wordfreq_dict = dict()
        for word in query_list:
            wordfreq_dict[word] = 0
        for word in query_list:
            x=text.count(word)
            wordfreq_dict[word] = wordfreq_dict[word] + x
        print("word  ","count")
        for i in wordfreq_dict.keys():
            print(i, wordfreq_dict[i])